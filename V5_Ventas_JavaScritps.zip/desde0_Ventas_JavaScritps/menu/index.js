
class MenuHandler {
    constructor() {
        this.menuContenido = document.getElementById('menuContenido');
        this.menuTitulo = document.getElementById('menuTitulo');
    }

    cambiarMenu(opcion) {
        switch (opcion) {
            case 'clientes':
                this.menuTitulo.innerText = 'MENU CLIENTE';
                this.menuContenido.innerHTML = `
                    <button>INGRESAR CLIENTE</button>
                    <button>ACTUALIZAR CLIENTE</button>
                    <button onclick="location.href='HTML/consultar.html'">Ir a Otra Página</button>
                    <a href="#" onclick="menuHandler.delete('clientes')"><button>ELIMINAR CLIENTE</button></a>
                `;
                break;
            case 'producto':
                this.menuTitulo.innerText = 'MENU PRODUCTO';
                this.menuContenido.innerHTML = `
                    <button>INGRESAR PRODUCTO</button>
                    <button>ACTUALIZAR PRODUCTO</button>
                    <button>CONSULTAR PRODUCTO</button>
                    <button>ELIMINAR PRODUCTO</button>
                `;
                break;
            case 'factura':
                this.menuTitulo.innerText = 'MENU FACTURA';
                this.menuContenido.innerHTML = `
                    <button>INGRESAR FACTURA</button>
                    <button>ACTUALIZAR FACTURA</button>
                    <button>CONSULTAR FACTURA</button>
                    <button>ELIMINAR FACTURA</button>
                `;
                break;
            default:
                break;
        }
    }
}
const menuHandler = new MenuHandler();
//     consult(opcion) {
//         switch (opcion) {
//             case 'clientes':
//                 this.menuTitulo.innerText = 'CONSULTAR CLIENTE';
//                 this.menuContenido.innerHTML = `
//                     <div class="ingresar">
//                         <label for="dni">Ingrese la cedula del cliente que desea consultar:</label>
//                         <input type="text" id="dni">
//                     </div>
//                     <div class="consulta">
//                         <button id="consultar" type="button">consultar</button>
//                         <table>
//                             <thead>
//                                 <tr>
//                                     <th>DNI</th>
//                                     <th>NOMBRE</th>
//                                     <th>APELLIDO</th>
//                                     <th>VALOR</th>
//                                 </tr>
//                                 <tbody id="table-container"></tbody>
//                             </thead>
//                         </table>
//                     </div>
//                 `;
//                 break;
//             case 'producto':
//                 this.menuTitulo.innerText = 'MENU PRODUCTO';
//                 this.menuContenido.innerHTML = `
//                     <button>INGRESAR PRODUCTO</button>
//                     <button>ACTUALIZAR PRODUCTO</button>
//                     <button>CONSULTAR PRODUCTO</button>
//                     <button>ELIMINAR PRODUCTO</button>
//                 `;
//                 break;
//             case 'factura':
//                 this.menuTitulo.innerText = 'MENU FACTURA';
//                 this.menuContenido.innerHTML = `
//                     <button>INGRESAR FACTURA</button>
//                     <button>ACTUALIZAR FACTURA</button>
//                     <button>CONSULTAR FACTURA</button>
//                     <button>ELIMINAR FACTURA</button>
//                 `;
//                 break;
//             default:
//                 break;
//         }
//     }
//     delete(opcion) {
//         switch (opcion) {
//             case 'clientes':
//                 this.menuTitulo.innerText = 'ELIMINAR CLIENTE';
//                 this.menuContenido.innerHTML = `
//                     <div class="ingresar">
//                         <label for="dni">Ingrese la cedula del cliente que desea eliminar</label>
//                         <input type="text" id="dni">
//                     </div>
//                     <div class="consulta">
//                         <button id="eliminar" type="button">Eliminar</button>
//                         <!-- <button id="consultar" type="button">consultar</button> -->
//                         <table>
//                             <thead>
//                                 <tr>
//                                     <th>DNI</th>
//                                     <th>NOMBRE</th>
//                                     <th>APELLIDO</th>
//                                     <th>VALOR</th>
//                                 </tr>
//                                 <tbody id="table-container"></tbody>
//                             </thead>
//                         </table>
//                     </div>
//                 `;
//                 break;
//             case 'producto':
//                 this.menuTitulo.innerText = 'MENU PRODUCTO';
//                 this.menuContenido.innerHTML = `
//                     <button>INGRESAR PRODUCTO</button>
//                     <button>ACTUALIZAR PRODUCTO</button>
//                     <button>CONSULTAR PRODUCTO</button>
//                     <button>ELIMINAR PRODUCTO</button>
//                 `;
//                 break;
//             case 'factura':
//                 this.menuTitulo.innerText = 'MENU FACTURA';
//                 this.menuContenido.innerHTML = `
//                     <button>INGRESAR FACTURA</button>
//                     <button>ACTUALIZAR FACTURA</button>
//                     <button>CONSULTAR FACTURA</button>
//                     <button>ELIMINAR FACTURA</button>
//                 `;
//                 break;
//             default:
//                 break;
//         }
//     }
//     save(opcion) {
//         switch (opcion) {
//             case 'clientes':
//                 this.menuTitulo.innerText = 'ELIMINAR CLIENTE';
//                 this.menuContenido.innerHTML = `
//                 <div id="formulario">
//                 <h2>Crear Cliente</h2>
//                 <table>
//                     <thead>
//                         <tr>
//                             <th>DNI</th>
//                             <th>NOMBRE</th>
//                             <th>APELLIDO</th>
//                             <th>VID</th>
//                             <th>TARJETA DE DESCUENTO</th>
//                         </tr>
//                         <tr>
//                             <td><input type="text" id="dni" name="dni" required></td>
//                             <td><input type="text" id="nombre" name="nombre" required></td>
//                             <td><input type="text" id="apellido" name="apellido" required></td>
//                             <td><select id="vip" name="vip">
//                                 <option value="si">Sí</option>
//                                 <option value="no">No</option>
//                             </select></td>
//                             <td><select id="descuento" name="descuento">
//                                 <option value="si">Sí</option>
//                                 <option value="no">No</option>
//                             </select></td>
//                         </tr>
//                     </thead>
//                 </table>
//                 <input type="submit" value="Guardar Cliente" id="guardar">
//                 <div id="Container"></div>
//                 <p></p>
            
//                 `;
//                 break;
//             case 'producto':
//                 this.menuTitulo.innerText = 'MENU PRODUCTO';
//                 this.menuContenido.innerHTML = `
//                     <button>INGRESAR PRODUCTO</button>
//                     <button>ACTUALIZAR PRODUCTO</button>
//                     <button>CONSULTAR PRODUCTO</button>
//                     <button>ELIMINAR PRODUCTO</button>
//                 `;
//                 break;
//             case 'factura':
//                 this.menuTitulo.innerText = 'MENU FACTURA';
//                 this.menuContenido.innerHTML = `
//                     <button>INGRESAR FACTURA</button>
//                     <button>ACTUALIZAR FACTURA</button>
//                     <button>CONSULTAR FACTURA</button>
//                     <button>ELIMINAR FACTURA</button>
//                 `;
//                 break;
//             default:
//                 break;
//         }
//     }
//     update(opcion) {
//         switch (opcion) {
//             case 'clientes':
//                 this.menuTitulo.innerText = 'ELIMINAR CLIENTE';
//                 this.menuContenido.innerHTML = `
//                     <h1>Actualizar Cliente</h1>
//                     <div>
//                         <label for="dni">Ingrese el DNI del cliente:</label>
//                         <input type="text" id="dni" name="dni">
//                         <button id="buscar">Buscar Cliente</button>
//                     </div>
//                     <br>
//                     <div id="Container"></div>
//                 `;
//                 break;
//             case 'producto':
//                 this.menuTitulo.innerText = 'MENU PRODUCTO';
//                 this.menuContenido.innerHTML = `
//                     <button>INGRESAR PRODUCTO</button>
//                     <button>ACTUALIZAR PRODUCTO</button>
//                     <button>CONSULTAR PRODUCTO</button>
//                     <button>ELIMINAR PRODUCTO</button>
//                 `;
//                 break;
//             case 'factura':
//                 this.menuTitulo.innerText = 'MENU FACTURA';
//                 this.menuContenido.innerHTML = `
//                     <button>INGRESAR FACTURA</button>
//                     <button>ACTUALIZAR FACTURA</button>
//                     <button>CONSULTAR FACTURA</button>
//                     <button>ELIMINAR FACTURA</button>
//                 `;
//                 break;
//             default:
//                 break;
//         }
//     }
// }


// //document.getElementById("cliente").onclick = menuHandler.cambiarMenu.bind(menuHandler);

