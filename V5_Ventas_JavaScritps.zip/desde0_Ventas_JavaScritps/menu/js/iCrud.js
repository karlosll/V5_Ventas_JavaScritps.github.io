export class prest {
    presentar(resp){
        return "Si existe entro en la clase"
    }
    
}

