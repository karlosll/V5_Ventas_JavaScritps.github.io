const path = require('path');

// __filename es una variable global en Node.js que devuelve la ruta del archivo actual.
const directoryPath = path.dirname(__filename);

console.log("path=", directoryPath);
