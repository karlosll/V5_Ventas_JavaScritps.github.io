class Client {
    constructor(firstName = "Consumidor", lastName = "Final", dni = "9999999999") {
        this.firstName = firstName;
        this.lastName = lastName;
        this._dni = dni;  // Atributo privado para almacenar el número de identificación del cliente
    }

    get dni() {
        // Getter para obtener el valor del atributo privado _dni
        return this._dni;
    }

    set dni(value) {
        // Setter para asignar un nuevo valor al número de identificación del cliente, con validación de longitud
        if (value.length === 10 || value.length === 13) {
            this._dni = value;
        } else {
            this._dni = "9999999999";  // Retorna el valor predeterminado si la longitud no es válida
        }
    }

    toString() {
        // Método especial para representar la clase Client como una cadena
        return `Cliente: ${this.firstName} ${this.lastName}`;
    }

    fullName() {
        return `${this.firstName} ${this.lastName}`;
    }

    show() {
        // Método para imprimir los detalles del cliente en la consola
        console.log('   Nombres    Dni');
        console.log(`${this.fullName()}  ${this.dni}`);
    }
}

class RegularClient extends Client {
    constructor(firstName = "Cliente", lastName = "Final", dni = "9999999999", card = false) {
        // Método constructor para inicializar los atributos de la clase RegularClient
        super(firstName, lastName, dni);  // Llama al constructor de la clase padre
        this._discount = card ? 0.10 : 0;  // Descuento del cliente regular
    }

    get discount() {
        // Getter para obtener el valor del descuento del cliente regular
        return this._discount;
    }

    toString() {
        // Método especial para representar la clase RegularClient como una cadena
        return `Cliente: ${this.firstName} ${this.lastName} Descuento: ${this.discount}`;
    }

    show() {
        // Método para imprimir los detalles del cliente regular en la consola
        console.log(`Cliente Regular: DNI: ${this.dni} Nombre: ${this.firstName} ${this.lastName} Descuento: ${this.discount * 100}%`);
    }

    getJson() {
        // Método para obtener los detalles del cliente regular en formato JSON
        return {
            dni: this.dni,
            nombre: this.firstName,
            apellido: this.lastName,
            valor: this.discount
        };
    }
}

class VipClient extends Client {
    constructor(firstName = "Consumidor", lastName = "Final", dni = "9999999999") {
        // Método constructor para inicializar los atributos de la clase VipClient
        super(firstName, lastName, dni);  // Llama al constructor de la clase padre
        this._limit = 10000;  // Límite de crédito del cliente VIP
    }

    get limit() {
        // Getter para obtener el valor del límite de crédito del cliente VIP
        return this._limit;
    }

    set limit(value) {
        // Setter para asignar un nuevo valor al límite de crédito del cliente VIP, con validación de rango
        this._limit = (value < 10000 || value > 20000) ? 10000 : value;
    }

    toString() {
        // Método especial para representar la clase VipClient como una cadena
        return `Cliente: ${this.firstName} ${this.lastName} Cupo: ${this.limit}`;
    }

    show() {
        // Método para imprimir los detalles del cliente VIP en la consola
        console.log(`Cliente Vip: DNI: ${this.dni} Nombre: ${this.firstName} ${this.lastName} Cupo: ${this.limit}`);
    }

    getJson() {
        // Método para obtener los detalles del cliente VIP en formato JSON
        return {
            dni: this.dni,
            nombre: this.firstName,
            apellido: this.lastName,
            valor: this.limit
        };
    }
}

class Valida {
    soloNumeros(mensajeError, col, fil) {
        while (true) {
            gotoxy(col, fil);
            let valor = prompt();
            try {
                if (parseInt(valor) > 0) {
                    break;
                }
            } catch (e) {
                gotoxy(col, fil); console.log(mensajeError);
                setTimeout(() => { gotoxy(col, fil); console.log(" ".repeat(20)); }, 1000);
            }
        }
        return valor;
    }

    soloNumeros2(mensajeError, col, fil) {
        while (true) {
            gotoxy(col, fil);
            let valor = prompt();
            try {
                if (parseInt(valor) >= 0) {
                    break;
                }
            } catch (e) {
                gotoxy(col, fil); console.log(mensajeError);
                setTimeout(() => { gotoxy(col, fil); console.log(" ".repeat(20)); }, 1000);
            }
        }
        return valor;
    }

    soloLetras(mensajeError, col, fil) {
        while (true) {
            gotoxy(col, fil);
            let valor = prompt();
            if (/^[a-zA-Z]+$/.test(valor)) {
                break;
            } else {
                gotoxy(col, fil); console.log(` ${mensajeError}`);
                setTimeout(() => { gotoxy(col, fil); console.log(" ".repeat(20)); }, 1000);
            }
        }
        return valor;
    }

    soloDecimales(mensajeError, col, fil) {
        while (true) {
            gotoxy(col, fil);
            let valor = prompt();
            try {
                valor = parseFloat(valor);
                if (valor > 0) {
                    break;
                }
            } catch (e) {
                gotoxy(col, fil); console.log(` ${mensajeError}`);
                setTimeout(() => { gotoxy(col, fil); console.log(" ".repeat(30)); }, 1000);
            }
        }
        return valor;
    }

    cedula(mensajeError) {
        while (true) {
            let valor = prompt();
            if (/^\d{10}$/.test(valor)) {
                break;
            } else {
                 console.log(mensajeError);
                setTimeout(() => { gotoxy(col, fil); console.log(" ".repeat(50)); }, 1000);
            }
        }
        return valor;
    }
}