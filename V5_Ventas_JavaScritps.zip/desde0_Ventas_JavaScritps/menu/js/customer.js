export class Client {
    constructor(firstName = "Consumidor", lastName = "Final", dni = "9999999999") {
        this.firstName = firstName;
        this.lastName = lastName;
        this._dni = dni;  // Atributo privado para almacenar el número de identificación del cliente
    }

    get dni() {
        // Getter para obtener el valor del atributo privado _dni
        return this._dni;
    }

    set dni(value) {
        // Setter para asignar un nuevo valor al número de identificación del cliente, con validación de longitud
        if (value.length === 10 || value.length === 13) {
            this._dni = value;
        } else {
            this._dni = "9999999999";  // Retorna el valor predeterminado si la longitud no es válida
        }
    }

    toString() {
        // Método especial para representar la clase Client como una cadena
        return `Cliente: ${this.firstName} ${this.lastName}`;
    }

    fullName() {
        return `${this.firstName} ${this.lastName}`;
    }

    show() {
        // Método para imprimir los detalles del cliente en la consola
        console.log('   Nombres    Dni');
        console.log(`${this.fullName()}  ${this.dni}`);
    }
}

export class RegularClient extends Client {
    constructor(firstName = "Cliente", lastName = "Final", dni = "9999999999", card = false) {
        // Método constructor para inicializar los atributos de la clase RegularClient
        super(firstName, lastName, dni);  // Llama al constructor de la clase padre
        this._discount = card ? 0.10 : 0;  // Descuento del cliente regular
    }

    get discount() {
        // Getter para obtener el valor del descuento del cliente regular
        return this._discount;
    }

    toString() {
        // Método especial para representar la clase RegularClient como una cadena
        return `Cliente: ${this.firstName} ${this.lastName} Descuento: ${this.discount}`;
    }

    show() {
        // Método para imprimir los detalles del cliente regular en la consola
        console.log(`Cliente Regular: DNI: ${this.dni} Nombre: ${this.firstName} ${this.lastName} Descuento: ${this.discount * 100}%`);
    }

    getJson() {
        // Método para obtener los detalles del cliente regular en formato JSON
        return {
            dni: this.dni,
            nombre: this.firstName,
            apellido: this.lastName,
            valor: this.discount
        };
    }
}

export class VipClient extends Client {
    constructor(firstName = "Consumidor", lastName = "Final", dni = "9999999999") {
        // Método constructor para inicializar los atributos de la clase VipClient
        super(firstName, lastName, dni);  // Llama al constructor de la clase padre
        this._limit = 10000;  // Límite de crédito del cliente VIP
    }

    get limit() {
        // Getter para obtener el valor del límite de crédito del cliente VIP
        return this._limit;
    }

    set limit(value) {
        // Setter para asignar un nuevo valor al límite de crédito del cliente VIP, con validación de rango
        this._limit = (value < 10000 || value > 20000) ? 10000 : value;
    }

    toString() {
        // Método especial para representar la clase VipClient como una cadena
        return `Cliente: ${this.firstName} ${this.lastName} Cupo: ${this.limit}`;
    }

    show() {
        // Método para imprimir los detalles del cliente VIP en la consola
        console.log(`Cliente Vip: DNI: ${this.dni} Nombre: ${this.firstName} ${this.lastName} Cupo: ${this.limit}`);
    }

    getJson() {
        // Método para obtener los detalles del cliente VIP en formato JSON
        return {
            dni: this.dni,
            nombre: this.firstName,
            apellido: this.lastName,
            valor: this.limit
        };
    }
}
