import { JsonFile } from "./clsjson.js";
import {prest} from "./iCrud.js";
import { VipClient,RegularClient } from "./customer.js";
class CrudClients {
    async update() {
        const clientesFile = new JsonFile('clients.json');
        const clientes = await clientesFile.read();
        const $Container = document.getElementById("Container");
        let dni = document.getElementById('dni').value;
        
        const cliente = await clientesFile.find('dni', dni);
        $Container.innerHTML = '';

        if (cliente.length > 0) {
            let cli = cliente[0];
            let clienteHtml = `
                <div>
                    <h3>CLIENTE</h3>
                    <p>${cli.valor ? "CLIENTE VIP" : "CLIENTE REGULAR"}</p>
                    <table>
                        <tr>
                            <th>Cedula</th>
                            <th>Nombre</th>
                            <th>Apellido</th>
                            <th>Valor</th>
                        </tr>
                        <tr>
                            <td>${cli.dni}</td>
                            <td><input type="text" id="new_name" value="${cli.nombre}"></td>
                            <td><input type="text" id="new_surname" value="${cli.apellido}"></td>
                            <td><input type="text" id="new_value" value="${cli.valor}"></td>
                        </tr>
                    </table>
                    <button id="update_button">Guardar</button>
                </div>
            `;
            $Container.innerHTML = clienteHtml;

            document.getElementById("update_button").addEventListener("click", async () => {
                let new_name = document.getElementById('new_name').value;
                let new_surname = document.getElementById('new_surname').value;
                let new_value = parseFloat(document.getElementById('new_value').value);
                
                for (let client of clientes) {
                    if (client.dni === dni) {
                        client.nombre = new_name;
                        client.apellido = new_surname;
                        client.valor = new_value;
                        break;
                    }
                }
                
                await clientesFile.save(clientes);
                $Container.innerHTML = `<p>Cliente actualizado exitosamente.</p>`;
            });
        } else {
            $Container.innerHTML = `<p>No se encontró ningún cliente con el dni proporcionado.</p>`;
        }
    }
    async save(){
        const clientesFile = new JsonFile('clients.json')
        const clientes = await clientesFile.read();
        const $Container = document.getElementById("Container");
        let dni = document.getElementById('dni').value;
        let name = document.getElementById('nombre').value;
        let lastname =  document.getElementById('apellido').value;
        let vip = document.getElementById('vip').value
        let descuento = document.getElementById('descuento').value
        console.log(dni,name,lastname,vip,descuento);
        const cliente = await clientesFile.find('dni',dni);
        let cards = false
        let tip,tip2
        console.log(clientes)
        $Container.innerHTML=''
        if (cliente.length>0) {
            $Container.innerHTML=` <p>EL CLIENTE YA EXISTE</p>`
        }else{
            if(vip=="si"){
                tip= new VipClient(name,lastname,dni)
                tip2= tip.getJson(tip)
            }else{
                if (descuento=="si"){ cards=true}
                tip=new RegularClient(name,lastname,dni,cards)
                tip2=tip.getJson(tip)
            }
            clientes.push(tip2)
            console.log(clientes)
            clientesFile.save(clientes)
            $Container.innerHTML=` <p>EL CIELTE YA SE GUARDO</p>`

        }

    }
    async delete(){
        const clientesFile = new JsonFile('clients.json')
        const clientes = await clientesFile.read();
        let dni = document.getElementById('dni').value;
        const $tableContainer = document.getElementById("table-container");
        const cliente = await clientesFile.find('dni',dni)
        $tableContainer.innerHTML=''
        if (cliente.length>0) {
            var valorIngresado = "n"
            valorIngresado = prompt("Esta seguro que desea eliminar el archivo(s/n):").toLowerCase();
            
            for(let item  of cliente){
                $tableContainer.innerHTML+=`
                                <tr>
                                <td>${item.dni}</td>
                                <td>${item.nombre}</td>
                                <td>${item.apellido}</td>
                                <td>${item.valor}</td>
                                </tr>   
                                `
            }
            if(valorIngresado=="s"){
                const eliminado = await clientesFile.delete('dni',dni)
                console.log(eliminado)
            }
        }else{
            
            for(let item  of clientes){
                $tableContainer.innerHTML+=`
                                <tr>
                                <td>${item.dni}</td>
                                <td>${item.nombre}</td>
                                <td>${item.apellido}</td>
                                <td>${item.valor}</td>
                                </tr>   
                                `
            }
        }
    }
    async consult() {
        const presentacion = new prest()
        const clientesFile = new JsonFile('clients.json')
        const clientes = await clientesFile.read();
        let dni = document.getElementById('dni').value;
        const $tableContainer = document.getElementById("table-container");
        const cliente = await clientesFile.find('dni',dni)
        console.log(clientes)
        console.log(cliente)
        //let cliente = json.   find("dni",dni)
        $tableContainer.innerHTML=''
        
        // Asumiendo que deseas comprobar si el DNI ha sido ingresado
        if (cliente.length>0) {
            
            for(let item  of cliente){
                $tableContainer.innerHTML+=`
                                <tr>
                                <td>${item.dni}</td>
                                <td>${item.nombre}</td>
                                <td>${item.apellido}</td>
                                <td>${item.valor}</td>
                                </tr>   
                                `
            }
        }else{
            for(let item  of clientes){
                $tableContainer.innerHTML+=`
                                <tr>
                                <td>${item.dni}</td>
                                <td>${item.nombre}</td>
                                <td>${item.apellido}</td>
                                <td>${item.valor}</td>
                                </tr>   
                                `
            }
        }
    }
}
class CrudProduct {
    capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
    }
    async save(){
        let descripcion = document.getElementById('descripcion').value;
        const precio = document.getElementById('precio').value;
        const stock = document.getElementById('stock').value;
        descripcion = this.capitalizeFirstLetter(descripcion);
        // Instanciamos la clase JsonFile para manejar el archivo de productos
        const productosFile = new JsonFile('products.json');

        try {
            const productos = await productosFile.read();
            const existingProduct = await productosFile.find('descripcion', descripcion);
            if (existingProduct.length > 0) {
                console.error('Error: Un producto con la misma descripción ya existe.');
                alert('Un producto con la misma descripción ya existe. Intente con una nueva descripción.');
                document.getElementById('descripcion').value = '';
                document.getElementById('precio').value = '';
                document.getElementById('stock').value = '';
                return;
            }

            // Asignar un ID único al nuevo producto
            const newId = productos.length > 0 ? Math.max(...productos.map(p => p.id)) + 1 : 1;

            // Crear un objeto producto con la información obtenida del formulario
            // Asegurarse de que 'id' sea la primera propiedad al crear el objeto
            const newProduct = {
                id: newId,
                descripcion: descripcion,
                precio: parseFloat(precio),
                stock: parseInt(stock)
            };

            // Añadir el nuevo producto al array
            productos.push(newProduct);

            // Guardar la lista actualizada en el servidor
            await productosFile.save(productos);
            console.log('Producto agregado exitosamente');
            alert('Producto agregado exitosamente!!');
            document.getElementById('descripcion').value = '';
            document.getElementById('precio').value = '';
            document.getElementById('stock').value = '';
        } catch (error) {
            console.error('Error al agregar el producto:', error);
        }
    }

    
    async delete(){
        const productosFile = new JsonFile('products.json')
        const productos = await productosFile.read();
        let descrip = document.getElementById('descripcion').value;
        const $tableContainer = document.getElementById("table-container");
        descrip = this.capitalizeFirstLetter(descrip);
        const producto = await productosFile.find('descripcion',descrip)
        $tableContainer.innerHTML=''
        if (producto.length>0) {
            var valorIngresado = "n"
            valorIngresado = prompt("Esta seguro que desea eliminar el archivo(s/n):").toLowerCase();
            
            for(let item  of producto){
                $tableContainer.innerHTML+=`
                                <tr>
                                <td>${item.id}</td>
                                <td>${item.descripcion}</td>
                                <td>${item.precio}</td>
                                <td>${item.stock}</td>
                                </tr>   
                                `
            }
            if(valorIngresado=="s"){
                const eliminado = await productosFile.delete('descripcion',descrip)
                console.log(eliminado)
            }
        }else{
            
            for(let item  of productos){
                $tableContainer.innerHTML+=`
                                <tr>
                                <td>${item.id}</td>
                                <td>${item.descripcion}</td>
                                <td>${item.precio}</td>
                                <td>${item.stock}</td>
                                </tr>      
                                `
            }
        }
    }
    async consult() {
        const presentacion = new prest()
        const productosFile = new JsonFile('products.json')
        const productos = await productosFile.read();
        let descrip = document.getElementById('descripcion').value;
        descrip = this.capitalizeFirstLetter(descrip);
        const $tableContainer = document.getElementById("table-container");
        const producto = await productosFile.find('descripcion',descrip)
        console.log(productos)
        console.log(producto)
        //let cliente = json.   find("dni",dni)
        $tableContainer.innerHTML=''
        
        // Asumiendo que deseas comprobar si el DNI ha sido ingresado
        if (producto.length>0) {
            
            for(let item  of producto){
                $tableContainer.innerHTML+=`
                                <tr>
                                <td>${item.id}</td>
                                <td>${item.descripcion}</td>
                                <td>${item.precio}</td>
                                <td>${item.stock}</td>
                                </tr>   
                                `
            }
        }else{
            for(let item  of productos){
                $tableContainer.innerHTML+=`
                                <tr>
                                <td>${item.id}</td>
                                <td>${item.descripcion}</td>
                                <td>${item.precio}</td>
                                <td>${item.stock}</td>
                                </tr>   
                                `
            }
        }
    }
    async update() {
        const id = parseInt(document.getElementById('product-id').value);
        let descripcion = document.getElementById('descripcion').value;
        const precio = document.getElementById('precio').value;
        const stock = document.getElementById('stock').value;
        descripcion = this.capitalizeFirstLetter(descripcion);

        const productosFile = new JsonFile('products.json');

        try {
            const productos = await productosFile.read();
            const index = productos.findIndex(p => p.id === id);

            if (index !== -1) {
                // Actualizar los datos del producto encontrado
                productos[index].descripcion = descripcion;
                productos[index].precio = parseFloat(precio);
                productos[index].stock = parseInt(stock);

                // Guardar la lista actualizada de productos en el servidor
                await productosFile.save(productos);
                console.log('Producto actualizado exitosamente');
                alert('Producto actualizado exitosamente');
                window.location.reload();
            } else {
                console.error('Producto no encontrado');
                alert('Producto no encontrado. Por favor, verifique el ID.');
            }
        } catch (error) {
            console.error('Error al actualizar el producto:', error);
        }
    }
}

var cli = new CrudClients();
var prod = new CrudProduct();

// document.getElementById("consultar").onclick = cli.consult.bind(cli);
// document.getElementById("buscar").onclick = cli.update.bind(cli);
document.addEventListener('DOMContentLoaded', function() {
    var consultarButton = document.getElementById("consultar");
    if (consultarButton) {
        consultarButton.onclick = cli.consult.bind(cli);
    }

    var buscarButton = document.getElementById("buscar");
    if (buscarButton) {
        buscarButton.onclick = cli.update.bind(cli);
    }

    var guardarButton = document.getElementById("guardar");
    if (guardarButton) {
        guardarButton.onclick = cli.save.bind(cli);
    }
    var eliminarButton = document.getElementById("eliminar");
    if (eliminarButton) {
        eliminarButton.onclick = cli.delete.bind(cli);
    }
    var consultarButtonP = document.getElementById("consultar");
    if (consultarButtonP) {
        consultarButtonP.onclick = prod.consult.bind(prod);
    }

    var buscarButtonP = document.getElementById("actualizar");
    if (buscarButtonP) {
        buscarButtonP.onclick = prod.update.bind(prod);
    }

    var guardarrButtonP = document.getElementById("ingresar");
    if (guardarrButtonP) {
        guardarrButtonP.onclick = prod.save.bind(prod);
    }

    var consultarButton = document.getElementById("eliminar");
    if (consultarButton) {
        consultarButton.onclick = prod.delete.bind(prod);
    }
});